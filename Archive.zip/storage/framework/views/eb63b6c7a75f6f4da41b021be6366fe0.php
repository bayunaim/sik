<div class="card shadow-sm">
    <div class="card-body p-4">
        <h4 class="mb-1">Lupa Password</h4>
        <p class="text-muted small mb-4">Masukkan email akun staf Anda untuk menerima tautan atur ulang password.</p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($terkirim): ?>
            <div class="alert alert-success">
                Jika email terdaftar sebagai akun staf yang aktif, tautan atur ulang password sudah dikirim. Periksa
                kotak masuk Anda.
            </div>
        <?php else: ?>
            <form wire:submit="kirim">
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" wire:model="email" autofocus
                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary w-100" wire:loading.attr="disabled"
                    wire:target="kirim">Kirim Tautan</button>
            </form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="mt-3 small">
            <a href="<?php echo e(route('login')); ?>">Kembali ke halaman masuk</a>
            <div class="text-muted mt-2">Mahasiswa yang lupa password: hubungi Bagian Keuangan.</div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/sik/resources/views/livewire/auth/lupa-password.blade.php ENDPATH**/ ?>