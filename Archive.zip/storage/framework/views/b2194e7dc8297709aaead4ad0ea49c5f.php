<div>
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <h4 class="mb-0">Rekonsiliasi Bank</h4>
        <div class="d-flex gap-2 flex-wrap">
            <a href="<?php echo e(route('rekonsiliasi.rekening')); ?>" class="btn btn-outline-secondary">Rekening Bank</a>
            <a href="<?php echo e(route('rekonsiliasi.import')); ?>" class="btn btn-outline-primary">
                <i class="cil-cloud-upload me-1"></i> Import Mutasi
            </a>
            <button class="btn btn-primary" wire:click="cocokOtomatis" wire:loading.attr="disabled"
                wire:target="cocokOtomatis"
                wire:confirm="Cocokkan otomatis semua mutasi Belum Cocok pada rekening dan periode yang dipilih?">
                <span wire:loading.remove wire:target="cocokOtomatis"><i class="cil-sync me-1"></i> Cocokkan Otomatis</span>
                <span wire:loading wire:target="cocokOtomatis">Memproses...</span>
            </button>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('sukses')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('sukses')); ?>

            <button type="button" class="btn-close" data-coreui-dismiss="alert"></button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('gagal')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo e(session('gagal')); ?>

            <button type="button" class="btn-close" data-coreui-dismiss="alert"></button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasilOtomatis): ?>
        <div class="alert alert-info alert-dismissible fade show">
            <?php echo e(number_format($hasilOtomatis['diproses'], 0, ',', '.')); ?> mutasi diproses:
            <strong><?php echo e(number_format($hasilOtomatis['cocok'], 0, ',', '.')); ?> cocok otomatis</strong>,
            <?php echo e(number_format($hasilOtomatis['ambigu'], 0, ',', '.')); ?> ambigu (lebih dari satu kandidat, cocokkan manual),
            <?php echo e(number_format($hasilOtomatis['tanpa_kandidat'], 0, ',', '.')); ?> tanpa kandidat.
            <button type="button" class="btn-close" data-coreui-dismiss="alert"></button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="row g-3 mb-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
            ['Belum Cocok', $ringkasan['belum_cocok'], 'warning'],
            ['Cocok', $ringkasan['cocok'], 'success'],
            ['Diabaikan', $ringkasan['diabaikan'], 'secondary'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $r, $warna]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="col-6 col-lg-3">
                <div class="card border-top-<?php echo e($warna); ?> border-top-3 h-100">
                    <div class="card-body">
                        <div class="text-body-secondary small"><?php echo e($label); ?></div>
                        <div class="fs-4 fw-semibold"><?php echo e(number_format($r['n'], 0, ',', '.')); ?></div>
                        <div class="small text-body-secondary">
                            Masuk Rp <?php echo e(number_format((float) $r['kredit'], 0, ',', '.')); ?><br>
                            Keluar Rp <?php echo e(number_format((float) $r['debit'], 0, ',', '.')); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <div class="col-6 col-lg-3">
            <div class="card border-top-danger border-top-3 h-100">
                <div class="card-body">
                    <div class="text-body-secondary small">Cocok bermasalah</div>
                    <div class="fs-4 fw-semibold"><?php echo e(number_format($ringkasan['bermasalah'], 0, ',', '.')); ?></div>
                    <div class="small text-body-secondary">Transaksinya sudah dibatalkan atau dihapus. Lepas dan cocokkan ulang.</div>
                </div>
            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sistem['masuk']['n'] > 0 || $sistem['keluar']['n'] > 0): ?>
        <div class="alert alert-light border small">
            Transaksi sistem (non-tunai) yang belum ditemukan di mutasi mana pun pada periode ini:
            <strong><?php echo e(number_format($sistem['masuk']['n'], 0, ',', '.')); ?> uang masuk</strong>
            (Rp <?php echo e(number_format((float) $sistem['masuk']['total'], 0, ',', '.')); ?>) dan
            <strong><?php echo e(number_format($sistem['keluar']['n'], 0, ',', '.')); ?> uang keluar</strong>
            (Rp <?php echo e(number_format((float) $sistem['keluar']['total'], 0, ',', '.')); ?>).
            Angka ini mencakup semua rekening karena transaksi belum mencatat rekening tujuannya.
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-header d-flex gap-2 flex-wrap align-items-center">
            <select class="form-select" style="max-width: 260px;" wire:model.live="rekeningId">
                <option value="">Semua rekening</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $daftarRekening; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->nama_bank); ?> - <?php echo e($r->nomor); ?><?php echo e($r->is_active ? '' : ' (nonaktif)'); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
            <select class="form-select" style="max-width: 170px;" wire:model.live="filterStatus">
                <option value="">Semua status</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\MutasiBank::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($nilai); ?>"><?php echo e($label); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <option value="bermasalah">Cocok bermasalah</option>
            </select>
            <input type="date" class="form-control" style="max-width: 160px;" wire:model.live="dari" title="Dari tanggal">
            <input type="date" class="form-control" style="max-width: 160px;" wire:model.live="sampai" title="Sampai tanggal">
            <input type="text" class="form-control" style="max-width: 240px;" placeholder="Cari keterangan atau referensi..."
                wire:model.live.debounce.400ms="cari">
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Tanggal</th>
                        <th>Rekening</th>
                        <th>Keterangan</th>
                        <th class="text-end">Debit (keluar)</th>
                        <th class="text-end">Kredit (masuk)</th>
                        <th>Status</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php $masalah = $row->cocokBermasalah(); ?>
                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'mut-'.e($row->id).''; ?>wire:key="mut-<?php echo e($row->id); ?>">
                            <td class="text-nowrap"><?php echo e($row->tanggal->format('d/m/Y')); ?></td>
                            <td class="small"><?php echo e($row->rekening?->nama_bank); ?><div class="text-body-secondary"><?php echo e($row->rekening?->nomor); ?></div></td>
                            <td style="max-width: 360px;">
                                <?php echo e($row->keterangan); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->referensi): ?>
                                    <div class="small text-body-secondary">Ref: <?php echo e($row->referensi); ?></div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="text-end"><?php echo e($row->isMasuk() ? '' : 'Rp '.number_format((float) $row->debit, 0, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e($row->isMasuk() ? 'Rp '.number_format((float) $row->kredit, 0, ',', '.') : ''); ?></td>
                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->status === 'cocok'): ?>
                                    <span class="badge bg-<?php echo e($masalah ? 'danger' : 'success'); ?>"><?php echo e($masalah ? 'Cocok, bermasalah' : 'Cocok'); ?></span>
                                    <div class="small text-body-secondary">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->cocok): ?>
                                            <?php echo e($svc->label($row->cocok)); ?>

                                        <?php else: ?>
                                            Transaksi sudah dihapus
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        (<?php echo e($row->cara_cocok); ?>)
                                    </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($masalah && $row->cocok): ?>
                                        <div class="small text-danger">Transaksi ini sudah tidak berlaku (dibatalkan).</div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php elseif($row->status === 'diabaikan'): ?>
                                    <span class="badge bg-secondary">Diabaikan</span>
                                    <div class="small text-body-secondary"><?php echo e($row->alasan_abaikan); ?></div>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Belum Cocok</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="text-end text-nowrap">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->status === 'belum_cocok'): ?>
                                    <button class="btn btn-sm btn-primary" wire:click="bukaCocok(<?php echo e($row->id); ?>)">Cocokkan</button>
                                    <button class="btn btn-sm btn-outline-secondary" wire:click="konfirmasiAbaikan(<?php echo e($row->id); ?>)">Abaikan</button>
                                <?php elseif($row->status === 'cocok'): ?>
                                    <button class="btn btn-sm btn-outline-danger" wire:click="lepas(<?php echo e($row->id); ?>)"
                                        wire:confirm="Lepas pencocokan mutasi ini?">Lepas</button>
                                <?php elseif($row->status === 'diabaikan'): ?>
                                    <button class="btn btn-sm btn-outline-secondary" wire:click="batalAbaikan(<?php echo e($row->id); ?>)">Batalkan abaikan</button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="7" class="text-center text-body-secondary py-4">
                                Tidak ada mutasi. Impor mutasi bank lewat tombol Import Mutasi.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->hasPages()): ?>
            <div class="card-footer"><?php echo e($data->links()); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mutasiCocok): ?>
        <div class="modal-backdrop fade show"></div>
        <div class="modal fade show d-block" tabindex="-1" style="overflow-y: auto;" wire:keydown.escape="tutupCocok">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Cocokkan Mutasi</h5>
                        <button type="button" class="btn-close" wire:click="tutupCocok"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-light border py-2">
                            <div class="small text-body-secondary">
                                <?php echo e($mutasiCocok->tanggal->format('d/m/Y')); ?> | <?php echo e($mutasiCocok->rekening?->nama_bank); ?>

                                <?php echo e($mutasiCocok->rekening?->nomor); ?>

                            </div>
                            <div><?php echo e($mutasiCocok->keterangan); ?></div>
                            <div class="fw-semibold">
                                <?php echo e($mutasiCocok->isMasuk() ? 'Uang masuk' : 'Uang keluar'); ?>

                                Rp <?php echo e(number_format((float) $mutasiCocok->nominal, 0, ',', '.')); ?>

                            </div>
                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['cocok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger py-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <input type="text" class="form-control mb-2" wire:model.live.debounce.300ms="cariKandidat"
                            placeholder="Cari nama, NIM, nomor kwitansi, atau keperluan...">
                        <div class="form-text mb-2">Hanya transaksi non-tunai dengan nominal yang sama persis dan belum
                            dicocokkan. Diurutkan dari tanggal terdekat.</div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $kandidat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div class="d-flex justify-content-between align-items-center border rounded p-2 mb-2"
                                <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'kand-'.e($k['type']).'-'.e($k['id']).''; ?>wire:key="kand-<?php echo e($k['type']); ?>-<?php echo e($k['id']); ?>">
                                <div>
                                    <div><?php echo e($k['label']); ?></div>
                                    <div class="small text-body-secondary"><?php echo e($k['tanggal']->format('d/m/Y')); ?></div>
                                </div>
                                <button class="btn btn-sm btn-primary"
                                    wire:click="pilih(<?php echo \Illuminate\Support\Js::from($k['type'])->toHtml() ?>, <?php echo e($k['id']); ?>)"
                                    wire:loading.attr="disabled">Pilih</button>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <div class="text-body-secondary text-center py-3">
                                Tidak ada transaksi dengan nominal yang sama. Jika selisihnya biaya admin atau bunga,
                                gunakan Abaikan dan sebutkan alasannya.
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="tutupCocok">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($abaikanId): ?>
        <div class="modal-backdrop fade show"></div>
        <div class="modal fade show d-block" tabindex="-1" wire:keydown.escape="tutupAbaikan">
            <div class="modal-dialog modal-dialog-centered">
                <form class="modal-content" wire:submit="simpanAbaikan">
                    <div class="modal-header">
                        <h5 class="modal-title">Abaikan Mutasi</h5>
                        <button type="button" class="btn-close" wire:click="tutupAbaikan"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-warning py-2 small">
                            Gunakan untuk mutasi yang memang tidak punya padanan di sistem, misalnya biaya admin bank atau
                            bunga. Mutasi ini tidak membuat jurnal. Jika perlu dibukukan, buat jurnal penyesuaian terpisah.
                        </div>
                        <label class="form-label">Alasan <span class="text-danger">*</span></label>
                        <textarea wire:model="alasanAbaikan" rows="3" class="form-control <?php $__errorArgs = ['alasanAbaikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['alasanAbaikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="tutupAbaikan">Kembali</button>
                        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled"
                            wire:target="simpanAbaikan">Abaikan Mutasi</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Applications/MAMP/htdocs/sik/resources/views/livewire/rekonsiliasi/index.blade.php ENDPATH**/ ?>