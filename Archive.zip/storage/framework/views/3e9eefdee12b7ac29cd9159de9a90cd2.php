<div>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Jurnal Umum</h4>
    </div>

    <div class="card">
        <div class="card-header d-flex gap-2 flex-wrap align-items-center">
            <input type="text" class="form-control" style="max-width: 280px;" placeholder="Cari nomor atau keterangan..."
                wire:model.live.debounce.400ms="cari">
            <input type="date" class="form-control" style="max-width: 170px;" wire:model.live="dari"
                title="Dari tanggal">
            <input type="date" class="form-control" style="max-width: 170px;" wire:model.live="sampai"
                title="Sampai tanggal">
        </div>

        <div class="table-responsive">
            <table class="table mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th style="width: 40px;"></th>
                        <th>Nomor</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Jenis</th>
                        <th class="text-end">Debit</th>
                        <th class="text-end">Kredit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'jr-'.e($row->id).''; ?>wire:key="jr-<?php echo e($row->id); ?>" wire:click="toggle(<?php echo e($row->id); ?>)"
                            style="cursor: pointer;">
                            <td><?php echo e($bukaId === $row->id ? '▾' : '▸'); ?></td>
                            <td class="fw-semibold text-nowrap"><?php echo e($row->nomor); ?></td>
                            <td class="text-nowrap"><?php echo e($row->tanggal->format('d/m/Y')); ?></td>
                            <td><?php echo e($row->keterangan); ?></td>
                            <td>
                                <span
                                    class="badge <?php echo e($row->jenis === 'pembalik' ? 'bg-warning text-dark' : ($row->jenis === 'penyesuaian' ? 'bg-info' : 'bg-secondary')); ?>">
                                    <?php echo e(ucfirst($row->jenis)); ?>

                                </span>
                            </td>
                            <td class="text-end">Rp <?php echo e(number_format($row->total_debit, 0, ',', '.')); ?></td>
                            <td class="text-end">Rp <?php echo e(number_format($row->total_kredit, 0, ',', '.')); ?></td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bukaId === $row->id): ?>
                            <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'jr-d-'.e($row->id).''; ?>wire:key="jr-d-<?php echo e($row->id); ?>" class="table-light">
                                <td></td>
                                <td colspan="6" class="p-0">
                                    <table class="table table-sm mb-0">
                                        <thead>
                                            <tr>
                                                <th>Akun</th>
                                                <th class="text-end">Debit</th>
                                                <th class="text-end">Kredit</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $row->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <tr>
                                                    <td
                                                        style="padding-left: <?php echo e((float) $d->kredit > 0 ? '2rem' : '0.5rem'); ?>;">
                                                        <?php echo e($d->akun?->kode); ?> - <?php echo e($d->akun?->nama); ?>

                                                    </td>
                                                    <td class="text-end">
                                                        <?php echo e((float) $d->debit > 0 ? 'Rp ' . number_format($d->debit, 0, ',', '.') : ''); ?>

                                                    </td>
                                                    <td class="text-end">
                                                        <?php echo e((float) $d->kredit > 0 ? 'Rp ' . number_format($d->kredit, 0, ',', '.') : ''); ?>

                                                    </td>
                                                </tr>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="7" class="text-center text-body-secondary py-4">Belum ada jurnal.</td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->hasPages()): ?>
            <div class="card-footer"><?php echo e($data->links()); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/sik/resources/views/livewire/jurnal/index.blade.php ENDPATH**/ ?>