<li class="nav-item dropdown" x-data="{ open: false }" @click.outside="open = false" wire:poll.30s>
    <a class="nav-link position-relative" href="#" role="button" aria-label="Notifikasi"
        :aria-expanded="open" @click.prevent="open = !open">
        <i class="cil-bell fs-5"></i>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jumlah > 0): ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                style="margin-left: -0.6rem; margin-top: 0.6rem;">
                <?php echo e($jumlah > 99 ? '99+' : $jumlah); ?>

                <span class="visually-hidden">belum dibaca</span>
            </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </a>

    <div class="dropdown-menu dropdown-menu-end p-0" :class="{ 'show': open }"
        style="position: absolute; top: 100%; right: 0; left: auto; width: 24rem; max-width: 92vw;">
        <div class="d-flex align-items-center justify-content-between bg-body-tertiary px-3 py-2 border-bottom">
            <span class="fw-semibold">Notifikasi</span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jumlah > 0): ?>
                <button type="button" class="btn btn-link btn-sm p-0" wire:click="tandaiSemua">Tandai semua dibaca</button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div style="max-height: 24rem; overflow-y: auto;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <button type="button" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'notif-'.e($n->id).''; ?>wire:key="notif-<?php echo e($n->id); ?>" wire:click="buka('<?php echo e($n->id); ?>')"
                    class="dropdown-item d-block text-wrap py-2 border-bottom <?php echo e($n->read_at ? '' : 'bg-body-tertiary'); ?>">
                    <div class="<?php echo e($n->read_at ? '' : 'fw-semibold'); ?>"><?php echo e($n->data['judul'] ?? 'Notifikasi'); ?></div>
                    <div class="small text-body-secondary"><?php echo e($n->data['pesan'] ?? ''); ?></div>
                    <div class="small text-body-secondary"><?php echo e($n->created_at->diffForHumans()); ?></div>
                </button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="px-3 py-4 text-center text-body-secondary small">Belum ada notifikasi.</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</li>
<?php /**PATH /Applications/MAMP/htdocs/sik/resources/views/livewire/lonceng.blade.php ENDPATH**/ ?>