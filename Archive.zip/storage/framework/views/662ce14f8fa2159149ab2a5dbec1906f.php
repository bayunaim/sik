<div>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Import Mutasi Bank</h4>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('rekonsiliasi.index')); ?>" class="btn btn-outline-secondary">Pencocokan</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($langkah > 1 && $langkah < 4): ?>
                <button class="btn btn-outline-secondary" wire:click="ulang"
                    wire:confirm="Batalkan import ini?">Batalkan</button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('sukses')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('sukses')); ?>

            <button type="button" class="btn-close" data-coreui-dismiss="alert"></button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="mb-3 small text-body-secondary">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['1. Unggah', '2. Pemetaan kolom', '3. Pratinjau', '4. Selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <span
                class="<?php echo e($langkah === $i + 1 ? 'fw-bold text-body' : ''); ?>"><?php echo e($s); ?></span><?php echo e($i < 3 ? ' > ' : ''); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($rekeningDipakai && $langkah > 1): ?>
            <span class="ms-3">Rekening: <strong><?php echo e($rekeningDipakai->nama_bank); ?> <?php echo e($rekeningDipakai->nomor); ?></strong></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['proses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($langkah === 1): ?>
        <div class="card mb-3">
            <div class="card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($daftarRekening->isEmpty()): ?>
                    <div class="alert alert-warning mb-0">
                        Belum ada rekening aktif. <a href="<?php echo e(route('rekonsiliasi.rekening')); ?>">Tambahkan rekening</a> dulu.
                    </div>
                <?php else: ?>
                    <label class="form-label">Rekening bank <span class="text-danger">*</span></label>
                    <select wire:model="pilihRekening" class="form-select mb-3 <?php $__errorArgs = ['pilihRekening'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">- Pilih rekening -</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $daftarRekening; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($r->id); ?>"><?php echo e($r->label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['pilihRekening'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block mb-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <label class="form-label">File mutasi (XLSX, XLS, atau CSV, maks. 10 MB)</label>
                    <input type="file" wire:model="berkas" accept=".xlsx,.xls,.csv,.txt"
                        class="form-control <?php $__errorArgs = ['berkas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['berkas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div wire:loading wire:target="berkas" class="form-text">Mengunggah...</div>
                    <div class="form-text">Baris judul kolom dicari otomatis, jadi baris info rekening di atas tabel
                        tidak masalah. File yang tumpang tindih dengan import sebelumnya aman: baris yang sudah ada
                        dilewati.</div>
                    <button class="btn btn-primary mt-3" wire:click="unggah" wire:loading.attr="disabled"
                        wire:target="unggah,berkas">
                        <span wire:loading.remove wire:target="unggah">Baca File</span>
                        <span wire:loading wire:target="unggah">Membaca...</span>
                    </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($langkah === 2): ?>
        <div class="card mb-3">
            <div class="card-header fw-semibold">Pemetaan kolom</div>
            <div class="card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['mapping'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger py-2"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="form-text mb-3">Petakan Debit dan Kredit jika bank memakai dua kolom. Jika hanya ada satu
                    kolom Jumlah, petakan Jumlah dan (kalau ada) kolom Jenis DB/CR; tanpa kolom Jenis, angka negatif
                    dianggap uang keluar.</div>
                <div class="row g-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kunci => $def): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo e($def['label']); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($def['wajib']): ?>
                                    <span class="text-danger">*</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </label>
                            <select wire:model="mapping.<?php echo e($kunci); ?>" class="form-select">
                                <option value="">- <?php echo e($def['wajib'] ? 'Pilih kolom' : 'Tidak dipakai'); ?> -</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($h); ?>"><?php echo e($h); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                <div class="form-check mt-3">
                    <input type="checkbox" class="form-check-input" id="tpl" wire:model="simpanTemplate">
                    <label class="form-check-label" for="tpl">Simpan pemetaan ini sebagai template untuk rekening ini</label>
                </div>
                <div class="form-check mt-2">
                    <input type="checkbox" class="form-check-input" id="auto" wire:model="cocokSetelah">
                    <label class="form-check-label" for="auto">Cocokkan otomatis setelah import selesai</label>
                </div>

                <button class="btn btn-primary mt-3" wire:click="buatPratinjau" wire:loading.attr="disabled"
                    wire:target="buatPratinjau">
                    <span wire:loading.remove wire:target="buatPratinjau">Buat Pratinjau</span>
                    <span wire:loading wire:target="buatPratinjau">Menganalisis...</span>
                </button>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($langkah === 3 && $pratinjau): ?>
        <div class="row g-3 mb-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [['Baru', $pratinjau['baru'], 'success'], ['Sudah ada (dilewati)', $pratinjau['duplikat'], 'secondary'], ['Tidak valid', $pratinjau['jumlah_error'], 'danger']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $n, $w]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="col-6 col-lg-3">
                    <div class="card border-top-<?php echo e($w); ?> border-top-3 h-100">
                        <div class="card-body">
                            <div class="text-body-secondary small"><?php echo e($l); ?></div>
                            <div class="fs-4 fw-semibold"><?php echo e(number_format($n, 0, ',', '.')); ?></div>
                        </div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="col-6 col-lg-3">
                <div class="card h-100">
                    <div class="card-body small">
                        <div class="text-body-secondary">Mutasi baru</div>
                        <div>Masuk Rp <?php echo e(number_format((float) $pratinjau['total_kredit'], 0, ',', '.')); ?></div>
                        <div>Keluar Rp <?php echo e(number_format((float) $pratinjau['total_debit'], 0, ',', '.')); ?></div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pratinjau['tanggal_awal']): ?>
                            <div class="text-body-secondary mt-1">
                                <?php echo e(\Carbon\Carbon::parse($pratinjau['tanggal_awal'])->format('d/m/Y')); ?> -
                                <?php echo e(\Carbon\Carbon::parse($pratinjau['tanggal_akhir'])->format('d/m/Y')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pratinjau['jumlah_error'] > 0): ?>
            <div class="card mb-3">
                <div class="card-header">Baris tidak valid (dilewati)<?php echo e($pratinjau['jumlah_error'] > 100 ? ', 100 pertama' : ''); ?>.
                    Daftar lengkap bisa diunduh setelah import disimpan.</div>
                <div class="table-responsive" style="max-height: 260px;">
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr><th>Baris</th><th>Tanggal</th><th>Keterangan</th><th>Alasan</th></tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pratinjau['error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td><?php echo e($e['baris']); ?></td>
                                    <td><?php echo e($e['tanggal']); ?></td>
                                    <td><?php echo e(\Illuminate\Support\Str::limit($e['keterangan'], 60)); ?></td>
                                    <td class="text-danger"><?php echo e($e['alasan']); ?></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pratinjau['contoh']): ?>
            <div class="card mb-3">
                <div class="card-header">Contoh mutasi baru (10 pertama)</div>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr><th>Tanggal</th><th>Keterangan</th><th class="text-end">Debit</th><th class="text-end">Kredit</th></tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pratinjau['contoh']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($c['tanggal'])->format('d/m/Y')); ?></td>
                                    <td><?php echo e(\Illuminate\Support\Str::limit($c['keterangan'], 70)); ?></td>
                                    <td class="text-end"><?php echo e((float) $c['debit'] > 0 ? number_format((float) $c['debit'], 0, ',', '.') : ''); ?></td>
                                    <td class="text-end"><?php echo e((float) $c['kredit'] > 0 ? number_format((float) $c['kredit'], 0, ',', '.') : ''); ?></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="d-flex gap-2">
            <button class="btn btn-outline-secondary" wire:click="kembali">Kembali</button>
            <button class="btn btn-primary" wire:click="proses" wire:loading.attr="disabled" wire:target="proses"
                <?php if($pratinjau['baru'] === 0): echo 'disabled'; endif; ?>
                wire:confirm="Simpan <?php echo e(number_format($pratinjau['baru'], 0, ',', '.')); ?> mutasi baru ke rekening ini?">
                <span wire:loading.remove wire:target="proses">Simpan Import</span>
                <span wire:loading wire:target="proses">Menyimpan...</span>
            </button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($langkah === 4 && $hasil): ?>
        <div class="alert alert-success">
            Import <strong><?php echo e($hasil['nama_file']); ?></strong> selesai: <?php echo e(number_format($hasil['jumlah_baru'], 0, ',', '.')); ?>

            mutasi baru, <?php echo e(number_format($hasil['jumlah_duplikat'], 0, ',', '.')); ?> sudah ada (dilewati),
            <?php echo e(number_format($hasil['jumlah_gagal'], 0, ',', '.')); ?> baris tidak valid.
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasil['error_path']): ?>
                <a href="<?php echo e(route('rekonsiliasi.import.error', $hasil['id'])); ?>">Unduh baris tidak valid (CSV)</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasilOtomatis): ?>
            <div class="alert alert-info">
                Pencocokan otomatis: <strong><?php echo e(number_format($hasilOtomatis['cocok'], 0, ',', '.')); ?> cocok</strong>,
                <?php echo e(number_format($hasilOtomatis['ambigu'], 0, ',', '.')); ?> ambigu,
                <?php echo e(number_format($hasilOtomatis['tanpa_kandidat'], 0, ',', '.')); ?> tanpa kandidat.
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('rekonsiliasi.index', ['rekeningId' => $rekeningId])); ?>" class="btn btn-primary">Lihat Pencocokan</a>
            <button class="btn btn-outline-secondary" wire:click="ulang">Import Lagi</button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card mt-4">
        <div class="card-header fw-semibold">Riwayat import</div>
        <div class="table-responsive">
            <table class="table table-sm mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Waktu</th><th>Rekening</th><th>File</th><th>Oleh</th>
                        <th class="text-end">Baru</th><th class="text-end">Dilewati</th><th class="text-end">Gagal</th>
                        <th>Status</th><th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'riw-'.e($r->id).''; ?>wire:key="riw-<?php echo e($r->id); ?>">
                            <td class="text-nowrap"><?php echo e($r->created_at->format('d/m/Y H:i')); ?></td>
                            <td><?php echo e($r->rekening?->nama_bank); ?> <?php echo e($r->rekening?->nomor); ?></td>
                            <td><?php echo e($r->nama_file); ?></td>
                            <td><?php echo e($r->user?->name); ?></td>
                            <td class="text-end"><?php echo e(number_format($r->jumlah_baru, 0, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($r->jumlah_duplikat, 0, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($r->jumlah_gagal, 0, ',', '.')); ?></td>
                            <td>
                                <?php $w = ['selesai' => 'success', 'gagal' => 'danger', 'dibatalkan' => 'secondary'][$r->status] ?? 'warning'; ?>
                                <span class="badge bg-<?php echo e($w); ?> <?php echo e($w === 'warning' ? 'text-dark' : ''); ?>" <?php if($r->catatan): ?> title="<?php echo e($r->catatan); ?>" <?php endif; ?>><?php echo e(ucfirst($r->status)); ?></span>
                            </td>
                            <td class="text-end text-nowrap">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($r->error_path): ?>
                                    <a href="<?php echo e(route('rekonsiliasi.import.error', $r->id)); ?>" class="btn btn-sm btn-outline-secondary">Error</a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($r->status === 'selesai'): ?>
                                    <button class="btn btn-sm btn-outline-danger" wire:click="konfirmasiBatal(<?php echo e($r->id); ?>)">Batalkan</button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr><td colspan="9" class="text-center text-body-secondary py-3">Belum ada import.</td></tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($batalId): ?>
        <div class="modal-backdrop fade show"></div>
        <div class="modal fade show d-block" tabindex="-1" wire:keydown.escape="tutupBatal">
            <div class="modal-dialog modal-dialog-centered">
                <form class="modal-content" wire:submit="simpanBatal">
                    <div class="modal-header">
                        <h5 class="modal-title">Batalkan Import</h5>
                        <button type="button" class="btn-close" wire:click="tutupBatal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-warning py-2 small">
                            Semua mutasi dari import ini dihapus (soft delete). Hanya bisa jika belum ada yang
                            dicocokkan atau diabaikan. Berguna kalau salah memilih rekening.
                        </div>
                        <label class="form-label">Alasan pembatalan <span class="text-danger">*</span></label>
                        <textarea wire:model="alasanBatal" rows="3" class="form-control <?php $__errorArgs = ['alasanBatal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['alasanBatal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="tutupBatal">Kembali</button>
                        <button type="submit" class="btn btn-danger" wire:loading.attr="disabled"
                            wire:target="simpanBatal">Batalkan Import</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Applications/MAMP/htdocs/sik/resources/views/livewire/rekonsiliasi/import.blade.php ENDPATH**/ ?>