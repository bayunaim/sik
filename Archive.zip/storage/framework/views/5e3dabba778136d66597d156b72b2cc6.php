<div>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-0">Dashboard</h4>
            <div class="text-body-secondary small">
                Halo, <?php echo e(auth()->user()->name); ?>.
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tahun): ?>
                    Tahun anggaran aktif: <strong><?php echo e($tahun->nama); ?></strong>.
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
        <div class="text-body-secondary"><?php echo e($bulanIni); ?></div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($tahun)): ?>
        <div class="alert alert-warning">Belum ada tahun anggaran aktif. Aktifkan satu di <strong>Data Master → Tahun
                Anggaran</strong>.</div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php $rp = fn ($n) => 'Rp '.number_format((float) $n, 0, ',', '.'); ?>

    <div class="row g-3 mb-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pembayaran.lihat')): ?>
            <div class="col-md-6 col-xl-3">
                <div class="card border-top-success border-top-3 h-100">
                    <div class="card-body">
                        <div class="text-body-secondary small">Pembayaran terverifikasi bulan ini
                            (<?php echo e($bayarLunas->jumlah ?? 0); ?>)</div>
                        <div class="fs-5 fw-semibold"><?php echo e($rp($bayarLunas->total ?? 0)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="card border-top-warning border-top-3 h-100">
                    <div class="card-body">
                        <div class="text-body-secondary small">Pembayaran pending bulan ini
                            (<?php echo e($bayarPending->jumlah ?? 0); ?>)</div>
                        <div class="fs-5 fw-semibold"><?php echo e($rp($bayarPending->total ?? 0)); ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pengeluaran.lihat')): ?>
            <div class="col-md-6 col-xl-3">
                <div class="card border-top-danger border-top-3 h-100">
                    <div class="card-body">
                        <div class="text-body-secondary small">Pengeluaran disetujui bulan ini</div>
                        <div class="fs-5 fw-semibold"><?php echo e($rp($keluarBulanIni)); ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tagihan.lihat')): ?>
            <div class="col-md-6 col-xl-3">
                <div class="card border-top-primary border-top-3 h-100">
                    <div class="card-body">
                        <div class="text-body-secondary small">Total tagihan tahun aktif</div>
                        <div class="fs-5 fw-semibold"><?php echo e($rp($totalTagihan)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="card border-top-danger border-top-3 h-100">
                    <div class="card-body">
                        <div class="text-body-secondary small">Total tunggakan
                            (<?php echo e(number_format($jumlahTunggakan, 0, ',', '.')); ?> tagihan)</div>
                        <div class="fs-5 fw-semibold text-danger"><?php echo e($rp($totalTunggakan)); ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($anggaranK)): ?>
            <div class="col-md-12 col-xl-6">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <span class="text-body-secondary small">Penggunaan anggaran pengeluaran</span>
                            <span class="fw-semibold"><?php echo e(number_format($persenPakai, 1, ',', '.')); ?>%</span>
                        </div>
                        <div class="progress my-2" style="height: 10px;">
                            <div class="progress-bar <?php echo e($persenPakai >= 90 ? 'bg-danger' : 'bg-primary'); ?>"
                                style="width: <?php echo e($persenPakai); ?>%"></div>
                        </div>
                        <div class="small text-body-secondary">
                            Terpakai <?php echo e($rp($terpakai)); ?> dari <?php echo e($rp($anggaranK)); ?>

                            | Target penerimaan <?php echo e($rp($anggaranD)); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <div class="row g-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pembayaran.verifikasi')): ?>
            <div class="col-lg-6">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span class="fw-semibold">Menunggu verifikasi (<?php echo e($totalMenungguVerifikasi); ?>)</span>
                        <a href="<?php echo e(route('pembayaran.index')); ?>" class="small">Lihat semua</a>
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $menungguVerifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span><?php echo e($p->mahasiswa?->nama); ?>

                                    <span class="small text-body-secondary d-block"><?php echo e($p->tagihan?->komponen?->nama); ?> |
                                        <?php echo e($p->tanggal_bayar->format('d/m/Y')); ?></span>
                                </span>
                                <span class="fw-semibold"><?php echo e($rp($p->nominal)); ?></span>
                            </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <li class="list-group-item text-body-secondary">Tidak ada yang menunggu.</li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pengeluaran.approve')): ?>
            <div class="col-lg-6">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span class="fw-semibold">Menunggu persetujuan (<?php echo e($totalMenungguApproval); ?>)</span>
                        <a href="<?php echo e(route('pengeluaran.index', ['filterStatus' => 'pending'])); ?>" class="small">Lihat
                            semua</a>
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $menungguApproval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span><?php echo e($p->keperluan); ?>

                                    <span class="small text-body-secondary d-block"><?php echo e($p->nomor); ?> |
                                        <?php echo e($p->pengaju?->name); ?></span>
                                </span>
                                <span class="fw-semibold"><?php echo e($rp($p->nominal)); ?></span>
                            </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <li class="list-group-item text-body-secondary">Tidak ada yang menunggu.</li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('Mahasiswa')): ?>
        <div class="alert alert-info">Portal tagihan dan pembayaran mahasiswa sedang disiapkan.</div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Applications/MAMP/htdocs/sik/resources/views/livewire/dashboard.blade.php ENDPATH**/ ?>